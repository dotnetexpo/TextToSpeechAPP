using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using TranslateTextApp.Business_Layer;
using Microsoft.CognitiveServices.Speech;
using Microsoft.CognitiveServices.Speech.Audio;
using System.Speech.Synthesis;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace TextToSpeechApp
{
    public class Program
    {
        

        public static object SpeechConfig { get; private set; }
        
        public static async Task Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
            await SynthesizeAudioAsync();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });

         static async Task SynthesizeAudioAsync()
        {
             var config =  Microsoft.CognitiveServices.Speech.SpeechConfig.FromSubscription("45ae4632b03c4f29aac847b4f31d9b90", "westus");

            config.SetSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat.Riff24Khz16BitMonoPcm);

            using var synthesizer = new Microsoft.CognitiveServices.Speech.SpeechSynthesizer(config, null);
            var result = await synthesizer.SpeakTextAsync("Customizing audio output format.");

            using var stream = AudioDataStream.FromResult(result);
            await stream.SaveToWaveFileAsync("path/to/write/file.wav");
        }




       
    }
}

