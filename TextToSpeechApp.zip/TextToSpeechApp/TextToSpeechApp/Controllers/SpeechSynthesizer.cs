﻿using System;
using System.Threading.Tasks;

namespace TranslateTextApp.Business_Layer
{
    internal class SpeechSynthesizer
    {
        private object config;
        private object p;

        public SpeechSynthesizer(object config, object p)
        {
            this.config = config;
            this.p = p;
        }

        internal Task SpeakSsmlAsync(string ssml)
        {
            throw new NotImplementedException();
        }
    }
}